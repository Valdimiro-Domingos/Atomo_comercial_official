<div class="row">
    <div class="col-xl-12">
        <div class="card">
            <div class="card-body">
                <div style="float: right; ">
                    <a href="{{ url('documentos/facturas/nova') }}" class="btn btn-warning"><i
                            class="fa fa-store font-size-16 align-middle mr-2"></i>AQUISIÇÂO (STOCK)</a>
                    <a data-toggle="modal" data-target=".novo-producto-servico" class="btn btn-success"><i
                            class="fa fa-bullhorn font-size-16 align-middle mr-2"></i>NOVO PRODUCTO/SERVIÇO</a>
                </div>
            </div>
        </div>
    </div>
</div>


