<div class="row">
    <div class="col-xl-12">
        <div class="card">
            <div class="card-body">
                <div style="float: right; ">
                    <a data-toggle="modal" data-target=".fornecedor" class="btn btn-success"><i
                            class="fa fa-bullhorn font-size-16 align-middle mr-2"></i>NOVO FORNECEDOR</a>
                </div>
            </div>
        </div>
    </div>
</div>


