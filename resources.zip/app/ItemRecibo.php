<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ItemRecibo extends Model
{
    //
}
