<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ItemEncomenda extends Model
{
    //
}
