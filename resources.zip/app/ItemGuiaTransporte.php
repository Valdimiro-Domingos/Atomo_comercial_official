<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ItemGuiaTransporte extends Model
{
    //
}
