<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ItemFacturaRecibo extends Model
{
    //
}
