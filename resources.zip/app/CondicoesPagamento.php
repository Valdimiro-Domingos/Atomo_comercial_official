<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CondicoesPagamento extends Model
{
    //
}
