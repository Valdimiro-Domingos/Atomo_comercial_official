<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class producto_servico_grupo extends Model
{
    protected $fillable = ['nome'];
}
